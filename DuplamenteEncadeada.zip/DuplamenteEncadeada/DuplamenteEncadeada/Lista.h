#pragma once
#include "Node.h";
#include <iostream>

using namespace std;

template <class T>
class Lista
{
public:
	Lista();
	~Lista();

private:
	Node<T> *start;
	int tamanho = 0;
	Node<T> *end;
	Lista(int tamanho, Node<T> *start);

public:
	void add(T *element);
	int size();
	bool isEmpty();
	int indexOf(T *element);
	bool contains(T *element);
	void clear();
	T get(int index);
	int lastindexOf(T *element);
	void add(int index, T *element);
	void remove(T *element);
	void remove(int index);
	T getHead();
	T getTail();
	bool isHead(T *element);
	bool isTail(T *element);
	T Next(T *element);
	Lista *separa_lista(int n);
	void print();
};

template<class T>
Lista<T>::Lista() {
	this->tamanho = 0;
	this->start = nullptr;
	this->end = nullptr;
}

template<class T>
inline Lista<T>::~Lista()
{
	this->tamanho = NULL;
	this->start = nullptr;
	this->end = nullptr;
}

template <class T>
Lista<T> ::Lista<T>(int tamanho, Node<T> *start) {
	this->tamanho = tamanho;
	this->Node<T> *start = Node<T> *start;
}


template <class T>
void Lista <T>::add(T* element) {
	if (!this->start) {
		Node<T> novoNo(element);
		std::cout<<"Adding"<<endl;
		this->start = &novoNo;
		this->end = &novoNo;
		tamanho++;
	}
	else {
		if (tamanho == 1) {
			Node<T> novoNo(element);
			Node<T>* pont = &novoNo;
			Node<T>* ptrAntes = start;
			start->proxno = pont;
			novoNo.noAnterior = ptrAntes;
			end = &novoNo;
			tamanho++;
		}
		else {
			Node<T> novoNo(element);
			Node<T> ultimoNo = *end;
			Node<T>* ptrUltimo = end;
			Node<T>* ptrNovo = &novoNo;
			ultimoNo.proxno = ptrNovo;
			novoNo.noAnterior = ptrUltimo;
			end = ptrNovo;
			tamanho++;
		}
	}
}

template <class T>
int Lista<T>::size() {
	return tamanho;
}

template<class T>
bool Lista<T>::isEmpty()
{
	if (tamanho == 0) {
		return true;
	}
	return false;
}

template<class T>
int Lista<T>::indexOf(T *element) {
	Node<T>* noAtual = start;
	int index = 0;
	while (noAtual) {
		if (element == (*noAtual).element) {
			return index;
		}
		noAtual = (*noAtual).proxno;
		index++;
	}
	return -1;
}

template<class T>
bool Lista<T> ::contains(T *element) {
	int index = this->indexOf(element);
	if (index != -1) {
		return true;
	}
	return false;
}

template<class  T>
void Lista<T>::clear() {
	start = nullptr;
	end = nullptr;
	tamanho = 0;
}

template<class T>
int Lista<T>::lastindexOf(T *element) {
	Node<T>* noAtual = end;
	int index = tamanho - 1;
	while (noAtual) {
		if (element == (*noAtual).element) {
			return index;
		}
		noAtual = (*noAtual).noAnterior;
		index--;
	}
	return -1;
}

template<class T>
T Lista<T>::get(int index) {
	Node<T>* noAtual = start;
	int indexAtual = 0;
	while (noAtual) {
		if (index == indexAtual) {
			return *(*noAtual).element;
		}
		else {
			noAtual = (*noAtual).proxno;
		}
		indexAtual++;
	}
	return NULL;
}

template <class T>
void Lista<T>::add(int index, T *element) {
	Node<T>* noAnterior = start;
	Node<T>* noAtual = (*start).proxno;
	int indexAtual = 0;

	if (index == 0) {
		Node<T> novoNo(element);
		novoNo.proxno = noAnterior;
		start = *novoNo;
		tamanho++;
		return;
	}

	while (noAnterior != nullptr) {
		if (index == indexAtual) {
			Node<T> novoNo(element);
			(*noAnterior).proxno = *novoNo;
			(*novoNo).proxno = noAtual;
		}
		else {
			noAnterior = noAtual;
			noAtual = (*noAtual).proxno;
		}
		indexAtual++;
	}
	tamanho++;
}

template <class T>
void Lista<T>::remove(T *element) {
	Node<T> noAtual = start;
	int indexAtual = 0;
	while (noAtual) {
		if ((*noAtual).element == element) {
			noAtual = (*(*noAtual).proxno).proxno;
		}
		else {
			noAtual = (*noAtual).proxno;
		}
		indexAtual++;
	}
}


template <class T>
void Lista<T>::remove(int index) {
	Node<T>* noAtual = start;
	int indexAtual = 0;
	while (noAtual) {
		if (index == indexAtual - 1) { 
			Node<T>* SaveNo = noAtual; 
			Node<T>* SaveNo2 = (*(*noAtual).proxno).proxno;
			(*noAtual).proxNo = SaveNo2;
			(*SaveNo2).noAnterior = SaveNo;
		}
		else {
			noAtual = (*noAtual).proxno;
			indexAtual++;
		}
	}
}

template <class T>
T Lista<T>::getHead() {
	return (*(*start).element);
}

template<class T>
T Lista<T>::getTail() {
	return (*(*end).element);
}

template<class T>
bool Lista<T>::isHead(T *element) {
	if ((*start).element == element) {
		return true;
	}
	return false;
}

template<class T>
bool Lista<T>::isTail(T *element) {
	if ((*end).element == element) {
		return true;
	}
	return false;
}

template<class T>
T Lista<T>::Next(T *element) {
	Node<T>* noAtual = start;
	while (noAtual) {
		if ((*noAtual).element == element) {
			return (*(*(*noAtual).proxno).element);
		}
		else {
			noAtual = (*noAtual).proxno;
		}
	}
}

template<class T>
Lista<T> * Lista<T>::separa_lista(int n)
{
	Node<T>* noAtual = start;
	int indexAchado = this->indexOf(n);
	int index = 0;
	while (noAtual) {
		if (index == indexAchado) {
			Lista<T> NewLista(((tamanho - indexAchado) + 1), (*noAtual).proxNo);
			NewLista.end = this->end;
			(*(*noAtual).proxNo).noAnterior = nullptr;
			end = noAtual;
			tamanho -= ((tamanho - indexAchado) + 1);
			(*noAtual).proxno = nullptr;
			return *NewLista;
		}
		else {
			noAtual = (*noAtual).proxno;
		}
		index++;
	}
	return nullptr;
}

template <class T>
void Lista<T>::print()
{
	Node<T>* noAtual = start;
	std::cout << "Print" << endl;
	while (noAtual) {
		//std::cout << "While" << endl;
		if (noAtual) {
			std::cout << "{";
			T obj = (*(*noAtual).element);
			std::cout << obj;
			noAtual = (*noAtual).proxno;
		}
		else {
			std::cout << "}";
		}
	}
}






