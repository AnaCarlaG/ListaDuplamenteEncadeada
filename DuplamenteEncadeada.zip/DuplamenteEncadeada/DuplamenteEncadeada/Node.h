#pragma once
template <class T>
class Node
{
public:
	Node(T *element);
	~Node();

public:
	Node *proxno;
	Node *noAnterior;
	T *element;
};

template <class T>
Node<T> ::Node(T *element) {
	this->element = element;
	this->proxno = nullptr;
	this->noAnterior = nullptr;
}

template<class T>
inline Node<T>::~Node()
{
	this->proxno = nullptr;
	this->noAnterior = nullptr;
	this->element = nullptr;
}
